from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QLabel, QCheckBox, 
                             QPushButton, QGroupBox, QFormLayout, QLineEdit)
from PyQt6.QtCore import Qt

class SettingsTab(QWidget):
    def __init__(self):
        super().__init__()
        self._init_ui()
    
    def _init_ui(self):
        layout = QVBoxLayout(self)
        
        scan_group = QGroupBox("Scanning Settings")
        scan_layout = QFormLayout()
        
        self.exclude_hidden = QCheckBox("Exclude hidden files and folders")
        self.exclude_hidden.setChecked(True)
        scan_layout.addRow("Hidden files:", self.exclude_hidden)
        
        self.exclude_system = QCheckBox("Exclude system folders")
        self.exclude_system.setChecked(True)
        scan_layout.addRow("System folders:", self.exclude_system)
        
        scan_group.setLayout(scan_layout)
        layout.addWidget(scan_group)
        
        playback_group = QGroupBox("Playback Settings")
        playback_layout = QFormLayout()
        
        self.vlc_path = QLineEdit()
        self.vlc_path.setPlaceholderText("Auto-detect")
        playback_layout.addRow("VLC Path:", self.vlc_path)
        
        playback_group.setLayout(playback_layout)
        layout.addWidget(playback_group)
        
        layout.addStretch()
        
        save_btn = QPushButton("Save Settings")
        save_btn.clicked.connect(self._on_save)
        layout.addWidget(save_btn)
    
    def _on_save(self):
        pass
