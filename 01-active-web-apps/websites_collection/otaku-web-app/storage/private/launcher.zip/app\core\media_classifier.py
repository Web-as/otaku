import re
from pathlib import Path
from typing import Tuple, Optional

class MediaClassifier:
    VIDEO_EXTENSIONS = {'.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.mpg', '.mpeg'}
    IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.tif'}
    ARCHIVE_EXTENSIONS = {'.zip', '.rar', '.7z', '.cbz', '.cbr'}
    
    ANIME_EPISODE_PATTERNS = [
        re.compile(r'[Ss](\d+)[Ee](\d+)'),
        re.compile(r'[Ee]pisode[\s_]?(\d+)', re.IGNORECASE),
        re.compile(r'[\s_\-](\d{1,3})[\s_\-]'),
        re.compile(r'[\s_\-]ep[\s_]?(\d+)', re.IGNORECASE),
    ]
    
    MANGA_KEYWORDS = ['manga', 'chapter', 'ch.', 'vol.', 'volume']
    CCG_KEYWORDS = ['card', 'tcg', 'ccg', 'yugioh', 'pokemon', 'mtg', 'magic']
    MOVIE_KEYWORDS = ['movie', 'film', 'gekijouban', '劇場版']
    
    @staticmethod
    def classify_file(file_path: str) -> Tuple[str, Optional[str], Optional[int]]:
        path = Path(file_path)
        ext = path.suffix.lower()
        name = path.stem.lower()
        parent_name = path.parent.name.lower()
        
        if ext in MediaClassifier.VIDEO_EXTENSIONS:
            return MediaClassifier._classify_video(name, parent_name, path)
        elif ext in MediaClassifier.IMAGE_EXTENSIONS or ext in MediaClassifier.ARCHIVE_EXTENSIONS:
            return MediaClassifier._classify_image_or_archive(name, parent_name, path)
        
        return ('unknown', None, None)
    
    @staticmethod
    def _classify_video(name: str, parent_name: str, path: Path) -> Tuple[str, Optional[str], Optional[int]]:
        combined = f"{parent_name} {name}"
        
        if any(keyword in combined for keyword in MediaClassifier.MOVIE_KEYWORDS):
            series_key = MediaClassifier._extract_series_name(name, path)
            return ('movies', series_key, None)
        
        for pattern in MediaClassifier.ANIME_EPISODE_PATTERNS:
            match = pattern.search(name)
            if match:
                groups = match.groups()
                episode_num = int(groups[-1])
                series_key = MediaClassifier._extract_series_name(name, path)
                return ('episodes', series_key, episode_num)
        
        series_key = MediaClassifier._extract_series_name(name, path)
        return ('episodes', series_key, None)
    
    @staticmethod
    def _classify_image_or_archive(name: str, parent_name: str, path: Path) -> Tuple[str, Optional[str], Optional[int]]:
        combined = f"{parent_name} {name}"
        
        if any(keyword in combined for keyword in MediaClassifier.MANGA_KEYWORDS):
            series_key = MediaClassifier._extract_series_name(name, path)
            chapter_num = MediaClassifier._extract_chapter_number(name)
            return ('manga', series_key, chapter_num)
        
        if any(keyword in combined for keyword in MediaClassifier.CCG_KEYWORDS):
            series_key = MediaClassifier._extract_series_name(name, path)
            card_num = MediaClassifier._extract_number(name)
            return ('ccg', series_key, card_num)
        
        if path.suffix.lower() in MediaClassifier.ARCHIVE_EXTENSIONS:
            series_key = MediaClassifier._extract_series_name(name, path)
            chapter_num = MediaClassifier._extract_chapter_number(name)
            return ('manga', series_key, chapter_num)
        
        series_key = MediaClassifier._extract_series_name(name, path)
        return ('ccg', series_key, None)
    
    @staticmethod
    def _extract_series_name(filename: str, path: Path) -> str:
        name = filename.lower()
        
        for pattern in MediaClassifier.ANIME_EPISODE_PATTERNS:
            name = pattern.sub('', name)
        
        name = re.sub(r'\[.*?\]', '', name)
        name = re.sub(r'\(.*?\)', '', name)
        name = re.sub(r'[\._\-]+', ' ', name)
        name = re.sub(r'\s+', ' ', name)
        name = name.strip()
        
        if not name or len(name) < 3:
            name = path.parent.name
        
        return name or 'unknown'
    
    @staticmethod
    def _extract_chapter_number(filename: str) -> Optional[int]:
        patterns = [
            re.compile(r'ch(?:apter)?[\s_\-]?(\d+)', re.IGNORECASE),
            re.compile(r'c(\d+)', re.IGNORECASE),
            re.compile(r'[\s_\-](\d+)[\s_\-]'),
        ]
        
        for pattern in patterns:
            match = pattern.search(filename)
            if match:
                return int(match.group(1))
        
        return None
    
    @staticmethod
    def _extract_number(filename: str) -> Optional[int]:
        match = re.search(r'(\d+)', filename)
        if match:
            return int(match.group(1))
        return None
    
    @staticmethod
    def normalize_series_key(series_name: str) -> str:
        normalized = series_name.lower()
        normalized = re.sub(r'[^\w\s]', '', normalized)
        normalized = re.sub(r'\s+', '_', normalized)
        return normalized
