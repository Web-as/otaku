from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLineEdit, QFileDialog, QProgressBar, QTextEdit,
                             QLabel, QMessageBox)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from services.scanner_service import ScannerService

class ScanWorker(QThread):
    progress = pyqtSignal(int, int, str)
    finished = pyqtSignal(dict)
    
    def __init__(self, scanner_service: ScannerService, folder_path: str):
        super().__init__()
        self.scanner_service = scanner_service
        self.folder_path = folder_path
    
    def run(self):
        result = self.scanner_service.scan_folder(
            self.folder_path,
            progress_callback=self._on_progress
        )
        self.finished.emit(result)
    
    def _on_progress(self, current: int, total: int, file_path: str):
        self.progress.emit(current, total, file_path)
    
    def stop(self):
        self.scanner_service.stop_scan()

class ScannerTab(QWidget):
    def __init__(self, scanner_service: ScannerService, library_tab):
        super().__init__()
        self.scanner_service = scanner_service
        self.library_tab = library_tab
        self.scan_worker = None
        self._init_ui()
    
    def _init_ui(self):
        layout = QVBoxLayout(self)
        
        info_label = QLabel(
            "Scan folders to catalog your media library.\n"
            "This process is NON-DESTRUCTIVE - files will not be moved, copied, or modified."
        )
        info_label.setStyleSheet("background-color: #e3f2fd; padding: 10px; border-radius: 5px;")
        layout.addWidget(info_label)
        
        folder_layout = QHBoxLayout()
        folder_layout.addWidget(QLabel("Folder to scan:"))
        
        self.folder_input = QLineEdit()
        self.folder_input.setPlaceholderText("Select a folder to scan...")
        folder_layout.addWidget(self.folder_input)
        
        self.browse_btn = QPushButton("Browse...")
        self.browse_btn.clicked.connect(self._on_browse)
        folder_layout.addWidget(self.browse_btn)
        
        layout.addLayout(folder_layout)
        
        button_layout = QHBoxLayout()
        self.scan_btn = QPushButton("Start Scan")
        self.scan_btn.clicked.connect(self._on_start_scan)
        button_layout.addWidget(self.scan_btn)
        
        self.stop_btn = QPushButton("Stop Scan")
        self.stop_btn.clicked.connect(self._on_stop_scan)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)
        
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("")
        layout.addWidget(self.status_label)
        
        layout.addWidget(QLabel("Scan Log:"))
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)
        
        layout.addStretch()
    
    def _on_browse(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder to Scan")
        if folder:
            self.folder_input.setText(folder)
    
    def _on_start_scan(self):
        folder_path = self.folder_input.text().strip()
        
        if not folder_path:
            QMessageBox.warning(self, "No Folder", "Please select a folder to scan.")
            return
        
        import os
        if not os.path.exists(folder_path):
            QMessageBox.warning(self, "Invalid Folder", "The selected folder does not exist.")
            return
        
        self.scan_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.browse_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.log_text.clear()
        self.log_text.append(f"Starting scan of: {folder_path}\n")
        
        self.scan_worker = ScanWorker(self.scanner_service, folder_path)
        self.scan_worker.progress.connect(self._on_progress)
        self.scan_worker.finished.connect(self._on_scan_finished)
        self.scan_worker.start()
    
    def _on_stop_scan(self):
        if self.scan_worker:
            self.log_text.append("\nStopping scan...")
            self.scan_worker.stop()
    
    def _on_progress(self, current: int, total: int, file_path: str):
        self.progress_bar.setMaximum(total)
        self.progress_bar.setValue(current)
        self.status_label.setText(f"Processing: {current}/{total} files")
        
        if current % 100 == 0:
            self.log_text.append(f"Processed {current} files...")
    
    def _on_scan_finished(self, result: dict):
        self.scan_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.browse_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        if result.get('success'):
            self.log_text.append(f"\n✓ Scan completed successfully!")
            self.log_text.append(f"Files found: {result['files_found']}")
            self.log_text.append(f"Files added to catalog: {result['files_added']}")
            
            if result.get('stopped'):
                self.log_text.append("\n(Scan was stopped by user)")
            
            self.status_label.setText("Scan completed")
            
            self.library_tab.refresh_library()
            
            QMessageBox.information(self, "Scan Complete", 
                                  f"Scan completed!\n\n"
                                  f"Files found: {result['files_found']}\n"
                                  f"Files added: {result['files_added']}")
        else:
            self.log_text.append(f"\n✗ Scan failed: {result.get('error', 'Unknown error')}")
            self.status_label.setText("Scan failed")
            
            QMessageBox.critical(self, "Scan Failed", 
                               f"Scan failed:\n{result.get('error', 'Unknown error')}")
        
        self.scan_worker = None
