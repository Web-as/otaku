import sqlite3
import os
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
import threading

class CatalogDatabase:
    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            app_data = Path.home() / "AppData" / "Local" / "OtakuLibrary"
            app_data.mkdir(parents=True, exist_ok=True)
            db_path = str(app_data / "catalog.db")
        
        self.db_path = db_path
        self._local = threading.local()
        self._init_database()
    
    def _get_connection(self):
        if not hasattr(self._local, 'conn'):
            self._local.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._local.conn.row_factory = sqlite3.Row
        return self._local.conn
    
    def _init_database(self):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS media_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                series_key TEXT NOT NULL,
                title TEXT NOT NULL,
                content_group TEXT NOT NULL CHECK (content_group IN ('episodes', 'movies', 'manga', 'ccg')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS media_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                media_item_id INTEGER NOT NULL,
                file_path TEXT NOT NULL UNIQUE,
                file_name TEXT NOT NULL,
                file_size INTEGER,
                file_mtime REAL,
                sequence_number INTEGER,
                thumbnail_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (media_item_id) REFERENCES media_items(id) ON DELETE CASCADE
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                media_file_id INTEGER NOT NULL UNIQUE,
                position_seconds REAL DEFAULT 0,
                duration_seconds REAL,
                completed BOOLEAN DEFAULT 0,
                last_watched TIMESTAMP,
                FOREIGN KEY (media_file_id) REFERENCES media_files(id) ON DELETE CASCADE
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scan_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT NOT NULL UNIQUE,
                enabled BOOLEAN DEFAULT 1,
                last_scan TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scan_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL,
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                files_found INTEGER DEFAULT 0,
                files_added INTEGER DEFAULT 0,
                status TEXT DEFAULT 'running',
                FOREIGN KEY (source_id) REFERENCES scan_sources(id) ON DELETE CASCADE
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ops_journal (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation_type TEXT NOT NULL,
                source_path TEXT,
                dest_path TEXT,
                status TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                metadata TEXT
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_media_items_series ON media_items(series_key)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_media_items_group ON media_items(content_group)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_media_files_item ON media_files(media_item_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_media_files_path ON media_files(file_path)")
        
        conn.commit()
    
    def add_scan_source(self, path: str) -> int:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO scan_sources (path) VALUES (?)", (path,))
        conn.commit()
        return cursor.lastrowid
    
    def get_scan_sources(self) -> List[Dict[str, Any]]:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM scan_sources WHERE enabled = 1")
        return [dict(row) for row in cursor.fetchall()]
    
    def start_scan_run(self, source_id: int) -> int:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO scan_runs (source_id) VALUES (?)", (source_id,))
        conn.commit()
        return cursor.lastrowid
    
    def complete_scan_run(self, run_id: int, files_found: int, files_added: int):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE scan_runs 
            SET completed_at = CURRENT_TIMESTAMP, 
                files_found = ?, 
                files_added = ?,
                status = 'completed'
            WHERE id = ?
        """, (files_found, files_added, run_id))
        conn.commit()
    
    def add_or_update_media_item(self, series_key: str, title: str, content_group: str) -> int:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM media_items WHERE series_key = ?", (series_key,))
        row = cursor.fetchone()
        
        if row:
            item_id = row[0]
            cursor.execute("""
                UPDATE media_items 
                SET title = ?, content_group = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (title, content_group, item_id))
        else:
            cursor.execute("""
                INSERT INTO media_items (series_key, title, content_group)
                VALUES (?, ?, ?)
            """, (series_key, title, content_group))
            item_id = cursor.lastrowid
        
        conn.commit()
        return item_id
    
    def add_media_file(self, media_item_id: int, file_path: str, file_name: str, 
                       file_size: int, file_mtime: float, sequence_number: Optional[int] = None) -> Optional[int]:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO media_files 
                (media_item_id, file_path, file_name, file_size, file_mtime, sequence_number)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (media_item_id, file_path, file_name, file_size, file_mtime, sequence_number))
            conn.commit()
            return cursor.lastrowid
        except sqlite3.IntegrityError:
            cursor.execute("""
                UPDATE media_files 
                SET file_size = ?, file_mtime = ?, sequence_number = ?
                WHERE file_path = ?
            """, (file_size, file_mtime, sequence_number, file_path))
            conn.commit()
            cursor.execute("SELECT id FROM media_files WHERE file_path = ?", (file_path,))
            row = cursor.fetchone()
            return row[0] if row else None
    
    def get_media_items_by_group(self, content_group: str) -> List[Dict[str, Any]]:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT mi.*, COUNT(mf.id) as file_count
            FROM media_items mi
            LEFT JOIN media_files mf ON mi.id = mf.media_item_id
            WHERE mi.content_group = ?
            GROUP BY mi.id
            ORDER BY mi.title
        """, (content_group,))
        return [dict(row) for row in cursor.fetchall()]
    
    def get_media_files_for_item(self, media_item_id: int) -> List[Dict[str, Any]]:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT mf.*, p.position_seconds, p.completed
            FROM media_files mf
            LEFT JOIN progress p ON mf.id = p.media_file_id
            WHERE mf.media_item_id = ?
            ORDER BY mf.sequence_number, mf.file_name
        """, (media_item_id,))
        return [dict(row) for row in cursor.fetchall()]
    
    def update_progress(self, media_file_id: int, position_seconds: float, 
                       duration_seconds: Optional[float] = None, completed: bool = False):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO progress (media_file_id, position_seconds, duration_seconds, completed, last_watched)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(media_file_id) DO UPDATE SET
                position_seconds = excluded.position_seconds,
                duration_seconds = COALESCE(excluded.duration_seconds, duration_seconds),
                completed = excluded.completed,
                last_watched = excluded.last_watched
        """, (media_file_id, position_seconds, duration_seconds, completed))
        conn.commit()
    
    def log_operation(self, operation_type: str, source_path: str, 
                     dest_path: Optional[str] = None, status: str = "pending", 
                     metadata: Optional[str] = None):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO ops_journal (operation_type, source_path, dest_path, status, metadata)
            VALUES (?, ?, ?, ?, ?)
        """, (operation_type, source_path, dest_path, status, metadata))
        conn.commit()
        return cursor.lastrowid
    
    def close(self):
        if hasattr(self._local, 'conn'):
            self._local.conn.close()
