import os
from pathlib import Path
from typing import List, Callable, Optional
from core.catalog_db import CatalogDatabase
from core.media_classifier import MediaClassifier

class ScannerService:
    def __init__(self, db: CatalogDatabase):
        self.db = db
        self.classifier = MediaClassifier()
        self._should_stop = False
    
    def scan_folder(self, folder_path: str, progress_callback: Optional[Callable[[int, int, str], None]] = None) -> dict:
        self._should_stop = False
        folder_path = os.path.abspath(folder_path)
        
        source_id = self.db.add_scan_source(folder_path)
        run_id = self.db.start_scan_run(source_id)
        
        files_found = 0
        files_added = 0
        
        try:
            all_files = self._enumerate_files(folder_path)
            total_files = len(all_files)
            
            for idx, file_path in enumerate(all_files):
                if self._should_stop:
                    break
                
                files_found += 1
                
                if progress_callback:
                    progress_callback(idx + 1, total_files, file_path)
                
                if self._process_file(file_path):
                    files_added += 1
            
            self.db.complete_scan_run(run_id, files_found, files_added)
            
            return {
                'success': True,
                'files_found': files_found,
                'files_added': files_added,
                'stopped': self._should_stop
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'files_found': files_found,
                'files_added': files_added
            }
    
    def _enumerate_files(self, folder_path: str) -> List[str]:
        files = []
        
        excluded_dirs = {'$RECYCLE.BIN', 'System Volume Information', 'Windows', 'Program Files', 
                        'Program Files (x86)', 'ProgramData', 'AppData', '.git', 'node_modules'}
        
        for root, dirs, filenames in os.walk(folder_path):
            dirs[:] = [d for d in dirs if d not in excluded_dirs and not d.startswith('.')]
            
            for filename in filenames:
                if not filename.startswith('.'):
                    file_path = os.path.join(root, filename)
                    files.append(file_path)
        
        return files
    
    def _process_file(self, file_path: str) -> bool:
        try:
            content_group, series_key, sequence_number = self.classifier.classify_file(file_path)
            
            if content_group == 'unknown':
                return False
            
            path = Path(file_path)
            file_stat = path.stat()
            
            normalized_key = self.classifier.normalize_series_key(series_key)
            title = series_key.replace('_', ' ').title()
            
            media_item_id = self.db.add_or_update_media_item(
                series_key=normalized_key,
                title=title,
                content_group=content_group
            )
            
            file_id = self.db.add_media_file(
                media_item_id=media_item_id,
                file_path=file_path,
                file_name=path.name,
                file_size=file_stat.st_size,
                file_mtime=file_stat.st_mtime,
                sequence_number=sequence_number
            )
            
            return file_id is not None
        
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            return False
    
    def stop_scan(self):
        self._should_stop = True
