from PyQt6.QtWidgets import (QMainWindow, QTabWidget, QWidget, QVBoxLayout, 
                             QStatusBar, QMessageBox)
from PyQt6.QtCore import Qt
from core.catalog_db import CatalogDatabase
from services.scanner_service import ScannerService
from services.catalog_service import CatalogService
from ui.tabs.library_tab import LibraryTab
from ui.tabs.scanner_tab import ScannerTab
from ui.tabs.tools_organizer_tab import ToolsOrganizerTab
from ui.tabs.settings_tab import SettingsTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Otaku Library Desktop")
        self.setGeometry(100, 100, 1200, 800)
        
        self.db = CatalogDatabase()
        self.scanner_service = ScannerService(self.db)
        self.catalog_service = CatalogService(self.db)
        
        self._init_ui()
    
    def _init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        
        self.library_tab = LibraryTab(self.catalog_service, self.db)
        self.scanner_tab = ScannerTab(self.scanner_service, self.library_tab)
        self.tools_tab = ToolsOrganizerTab(self.db)
        self.settings_tab = SettingsTab()
        
        self.tabs.addTab(self.library_tab, "Library")
        self.tabs.addTab(self.scanner_tab, "Scanner")
        self.tabs.addTab(self.tools_tab, "Tools")
        self.tabs.addTab(self.settings_tab, "Settings")
        
        layout.addWidget(self.tabs)
        
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
    
    def closeEvent(self, event):
        self.db.close()
        event.accept()
