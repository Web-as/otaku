from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QListWidget, QLabel, QComboBox, QListWidgetItem,
                             QSplitter, QTextEdit, QMessageBox)
from PyQt6.QtCore import Qt, pyqtSignal
from services.catalog_service import CatalogService
from core.catalog_db import CatalogDatabase
import os

class LibraryTab(QWidget):
    def __init__(self, catalog_service: CatalogService, db: CatalogDatabase):
        super().__init__()
        self.catalog_service = catalog_service
        self.db = db
        self.current_content_type = 'episodes'
        self._init_ui()
    
    def _init_ui(self):
        layout = QVBoxLayout(self)
        
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Content Type:"))
        
        self.type_combo = QComboBox()
        self.type_combo.addItems(['Episodes', 'Movies', 'Manga', 'CCG'])
        self.type_combo.currentTextChanged.connect(self._on_type_changed)
        filter_layout.addWidget(self.type_combo)
        
        filter_layout.addStretch()
        
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh_library)
        filter_layout.addWidget(self.refresh_btn)
        
        layout.addLayout(filter_layout)
        
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        self.series_list = QListWidget()
        self.series_list.itemClicked.connect(self._on_series_selected)
        splitter.addWidget(self.series_list)
        
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        self.series_title_label = QLabel("Select a series")
        self.series_title_label.setStyleSheet("font-size: 16px; font-weight: bold;")
        right_layout.addWidget(self.series_title_label)
        
        self.files_list = QListWidget()
        self.files_list.itemDoubleClicked.connect(self._on_file_double_clicked)
        right_layout.addWidget(self.files_list)
        
        button_layout = QHBoxLayout()
        self.play_btn = QPushButton("Play/Open")
        self.play_btn.clicked.connect(self._on_play_clicked)
        self.play_btn.setEnabled(False)
        button_layout.addWidget(self.play_btn)
        
        button_layout.addStretch()
        right_layout.addLayout(button_layout)
        
        splitter.addWidget(right_panel)
        splitter.setSizes([400, 800])
        
        layout.addWidget(splitter)
        
        self.refresh_library()
    
    def _on_type_changed(self, text: str):
        self.current_content_type = text.lower()
        self.refresh_library()
    
    def refresh_library(self):
        self.series_list.clear()
        self.files_list.clear()
        self.series_title_label.setText("Select a series")
        self.play_btn.setEnabled(False)
        
        items = self.catalog_service.get_library_by_type(self.current_content_type)
        
        for item in items:
            list_item = QListWidgetItem(f"{item['title']} ({item['file_count']} files)")
            list_item.setData(Qt.ItemDataRole.UserRole, item)
            self.series_list.addItem(list_item)
        
        if not items:
            self.series_list.addItem("No items found. Use Scanner tab to add media.")
    
    def _on_series_selected(self, item: QListWidgetItem):
        data = item.data(Qt.ItemDataRole.UserRole)
        if not data:
            return
        
        self.series_title_label.setText(data['title'])
        self.files_list.clear()
        
        files = self.catalog_service.get_files_for_series(data['id'])
        
        for file_data in files:
            file_name = file_data['file_name']
            if file_data.get('sequence_number'):
                file_name = f"#{file_data['sequence_number']} - {file_name}"
            
            if file_data.get('completed'):
                file_name += " ✓"
            elif file_data.get('position_seconds', 0) > 0:
                file_name += " ▶"
            
            file_item = QListWidgetItem(file_name)
            file_item.setData(Qt.ItemDataRole.UserRole, file_data)
            self.files_list.addItem(file_item)
        
        self.play_btn.setEnabled(len(files) > 0)
    
    def _on_file_double_clicked(self, item: QListWidgetItem):
        self._play_file(item)
    
    def _on_play_clicked(self):
        current_item = self.files_list.currentItem()
        if current_item:
            self._play_file(current_item)
    
    def _play_file(self, item: QListWidgetItem):
        file_data = item.data(Qt.ItemDataRole.UserRole)
        if not file_data:
            return
        
        file_path = file_data['file_path']
        
        if not os.path.exists(file_path):
            QMessageBox.warning(self, "File Not Found", 
                              f"The file no longer exists:\n{file_path}")
            return
        
        try:
            os.startfile(file_path)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open file:\n{str(e)}")
