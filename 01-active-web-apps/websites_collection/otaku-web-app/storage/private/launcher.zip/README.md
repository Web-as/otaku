# Otaku Library Desktop

A unified desktop application for cataloging and managing your anime, manga, and media library.

## Features

### Non-Destructive Library Launcher (Default Mode)
- **Scan folders** to catalog media without moving or copying files
- **Auto-categorization** into Episodes, Movies, Manga, and CCG
- **Browse library** by content type with filtering
- **Play/Open media** directly from the library interface
- **Track progress** for watched episodes and read chapters
- **Persistent catalog** stored in local SQLite database

### Content Types Supported
- **Anime Episodes**: Automatically detects series and episode numbers
- **Anime Movies**: Identifies standalone movie files
- **Manga**: Supports archives (.cbz, .cbr) and image folders
- **CCG (Trading Cards)**: Catalogs card game image collections

### Safety Features
- **Non-destructive scanning**: Files remain in their original locations
- **No automatic file operations**: Scanning never modifies source files
- **Organizer tools isolated**: File moving/copying requires explicit opt-in (Tools tab)
- **Preview-first workflow**: All destructive operations show preview before execution
- **Audit logging**: All file operations are logged for review

## Installation

### Prerequisites
- Python 3.8 or higher
- VLC Media Player (for video playback)

### Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   cd app
   python main.py
   ```

## Usage

### First-Time Setup
1. Launch the application
2. Go to the **Scanner** tab
3. Click "Browse..." and select a folder containing your media
4. Click "Start Scan" to catalog your files
5. Switch to the **Library** tab to browse your cataloged media

### Browsing Your Library
1. Select content type from the dropdown (Episodes, Movies, Manga, CCG)
2. Click on a series/item in the left panel
3. View files in the right panel
4. Double-click or click "Play/Open" to launch media

### Rescanning
- Use the "Refresh" button in Scanner tab to update your catalog
- Rescanning preserves watch/read progress for existing files
- New files are automatically added to the catalog

## Architecture

### Project Structure
```
otaku-library-desktop/
  app/
    main.py                 # Application entry point
    core/
      catalog_db.py         # SQLite database management
      media_classifier.py   # File categorization logic
    services/
      scanner_service.py    # Non-destructive scanning
      catalog_service.py    # Library data access
    ui/
      main_window.py        # Main application window
      tabs/
        library_tab.py      # Library browsing UI
        scanner_tab.py      # Scanning interface
        tools_organizer_tab.py  # File organization tools (Phase 3)
        settings_tab.py     # Application settings
```

### Database Schema
- **media_items**: Series/collections (anime, manga, CCG sets)
- **media_files**: Individual files with metadata and sequence numbers
- **progress**: Watch/read progress tracking
- **scan_sources**: Configured scan folders
- **scan_runs**: Scan history and statistics
- **ops_journal**: Audit log for file operations

## Development Phases

### Phase 1 (Current) ✓
- Unified project structure
- Non-destructive scanning pipeline
- Media categorization (episodes/movies/manga/ccg)
- Library browsing UI
- Basic playback integration

### Phase 2 (Planned)
- Enhanced playback with embedded VLC player
- Manga/image viewer integration
- Thumbnail generation
- Advanced filtering and search

### Phase 3 (Planned)
- Organizer tools with preview-first workflow
- File moving/copying with confirmation gates
- Undo functionality
- Comprehensive audit logging

### Phase 4 (Planned)
- Converter tools integration
- Batch processing capabilities
- Packaging as standalone executable

## Important Notes

### Non-Destructive Guarantee
The default scanning and library features **never modify your files**. They only:
- Read file metadata
- Store file paths in the database
- Generate thumbnails in app data folder
- Track playback progress

### Organizer Tools
File organization features (move/copy/rename) are:
- Located in the **Tools** tab (not part of default workflow)
- Disabled by default
- Preview-first (dry-run mode)
- Require explicit user confirmation
- Fully logged in audit trail

## Troubleshooting

### VLC Not Found
If video playback fails:
1. Install VLC Media Player from videolan.org
2. Ensure VLC is in your system PATH
3. Or configure VLC path in Settings tab

### Files Not Appearing in Library
1. Check that files have supported extensions
2. Verify folder was scanned successfully in Scanner tab
3. Use "Refresh" button in Library tab
4. Check scan log for errors

### Database Location
The catalog database is stored at:
```
%LOCALAPPDATA%\OtakuLibrary\catalog.db
```

## License
Internal use - Otaku Gildija project
