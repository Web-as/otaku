from typing import List, Dict, Any
from core.catalog_db import CatalogDatabase

class CatalogService:
    def __init__(self, db: CatalogDatabase):
        self.db = db
    
    def get_library_by_type(self, content_type: str) -> List[Dict[str, Any]]:
        return self.db.get_media_items_by_group(content_type)
    
    def get_files_for_series(self, media_item_id: int) -> List[Dict[str, Any]]:
        return self.db.get_media_files_for_item(media_item_id)
    
    def get_all_content_types(self) -> List[str]:
        return ['episodes', 'movies', 'manga', 'ccg']
    
    def search_library(self, query: str, content_type: Optional[str] = None) -> List[Dict[str, Any]]:
        pass
